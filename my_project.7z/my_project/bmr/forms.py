from django import forms


class BmrForm(forms.Form):
	genders = (
		("M", "Мужчина"),
		("F", "Женщина"),
	)
	gender = forms.ChoiseField(choices=genders, label="пол")
	height = forms.IntegerField(min_value=1, label="рост в см")
	weight = forms.IntegerField(min_value=1, label="вес в кг")
	age = forms.IntegerField(min_value=1, label="возраст в годах")
	activity = forms.ChoiceField(
		(1.2, "Сидячий образ жизни без нагрузок"),
		(1.375, "Тренировки 1-3 раза в неделю"),
		(1.55, "Интенсивные тренировки 6-7 раз в неделю"),
		(1.9, "Спортсмены, выполняющие упражнения чаще, чем раз в день"))