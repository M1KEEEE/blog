from django.shortcuts import render
from .forms import BmrForm


# Create your views here.
def index(request):
	if request.method == "GET":
		form = BmrForm()
		return render(request, "bmr/index.html", {"form": form})

def result(request):
	pass
