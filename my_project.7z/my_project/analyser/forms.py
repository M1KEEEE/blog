from django.forms import Form


class AnalyserForm(Form):
	source_file_path = Form.FileField(label="путь к файлу с текстом")
	parts_of_speech=[
	("NOUN", "имя существительное"),
	("ADJF", "имя прилагательное (полное)"),
	("ADJS", "имя прилагательное (краткое)"),
	("COMP", "компаратив"),
	("VERB", "глагол (личная форма)")
	]
	parts_of_speech = forms.ChoiceField(label="части речи", choices=parts_of_speech, widget=forms.RadioSelect)
