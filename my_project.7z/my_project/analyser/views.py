from django.shortcuts import render

# Create your views here.
def index(request):
	form = forms.AnalyserForm
	return render(request, "analyser/index.html", {"form": form})