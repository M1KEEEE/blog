from django.shortcuts import render
import datetime

def index(request):
    now = datetime.datetime.now()
    return render(
        request,
        "my_app/index.html",
        {"is_new_year": now.day == 1 and mow.month == 1}
    )
