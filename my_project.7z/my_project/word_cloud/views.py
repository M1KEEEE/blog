from django.shortcuts import render
from . import analyser
from . import forms


def index(request):
    """
    FIXME: поля source_file_path, dest_file_path, не проходят валидацию
    FIXME: поле wordcloud_background_color не джанговое, не проходит валидацию тоже
    """
    if request.method == "POST":
        form = forms.AnalyserForm(request.POST, request.FILES)
        handle_uploaded_file(request.FILES["source_file_content"])
        if form.is_valid():
            analyser.Analyser(
                source_file_path=r"C:\Users\DDT\Desktop\my_project\word_cloud\text.txt",
                dest_file_path=r"C:\Users\DDT\Desktop\my_project\word_cloud\static\word_cloud\wordcloud.jpg",
                parts_of_speech=form.cleaned_data["part_of_speech"],
                words_num=form.cleaned_data["words_num"],
                wordcloud_width=form.cleaned_data["wordcloud_width"],
                wordcloud_height=form.cleaned_data["wordcloud_height"]
            )
            return render(request, "text_analyser/result.html")
        else:
            return render(request, "text_analyser/index.html", {"form": form})
    else:
        form = forms.AnalyserForm()
        return render(request, "text_analyser/index.html", {"form": form})

def handle_uploaded_file(f):
    with open(r"C:\Users\DDT\Desktop\my_project\word_cloud\text.txt", 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)