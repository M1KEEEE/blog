from datetime import datetime
from django.shortcuts import render
from django import forms

tasks = ["первое", "второе", "третье"]

class NewTaskForm(form.Form):
	task = form.CharField(label="Новая задача")
	priority = forms.IntegerField(
		label="приоритет",
		min_value=1,
		max_value=10
	)

form = NewTaskForm()

def index(request):
	return render(
		request, 
		"tasks/index.html", 
		{"tasks": tasks})

def add(request):
