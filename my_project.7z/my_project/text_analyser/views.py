from django.shortcuts import render
from . import analyser
from . import forms


def index(request):
    """
    FIXME: поля source_file_path, dest_file_path, не проходят валидацию
    FIXME: поле wordcloud_background_color не джанговое, не проходит валидацию тоже
    """
    if request.method == "POST":
        form = forms.AnalyserForm(request.POST, request.FILES)
        print(form)
        if form.is_valid():
            wordcloud_background_color=request.POST["wordcloud_background_color"]
            analyser.Analyser(
                source_file_path=r"C:\Users\DDT\Desktop\my_project_1\my_project\text_analyser\static\text_analyser\texts\text.txt",
                dest_file_path=r"text_analyser\static\text_analyser\wordcloud.jpg",
                parts_of_speech=form.cleaned_data["part_of_speech"],
                words_num=form.cleaned_data["words_num"],
                wordcloud_width=form.cleaned_data["wordcloud_width"],
                wordcloud_height=form.cleaned_data["wordcloud_height"],
                wordcloud_background_color=wordcloud_background_color
            )
            return render(request, "text_analyser/result.html", {"wordcloud_background_color": wordcloud_background_color})
        else:
            return render(request, "text_analyser/index.html", {"form": form})
    else:
        form = forms.AnalyserForm()
        return render(request, "text_analyser/index.html", {"form": form})